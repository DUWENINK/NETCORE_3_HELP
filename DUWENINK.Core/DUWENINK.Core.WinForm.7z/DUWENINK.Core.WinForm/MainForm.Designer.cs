﻿namespace DUWENINK.Core.WinForm
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmMian = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmCreateDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmLogPath = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmCreateMySql = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmMini = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvMessageInfo = new System.Windows.Forms.DataGridView();
            this.CreateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LogMessageTypeText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MessageText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tslTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslName = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.niMini = new System.Windows.Forms.NotifyIcon(this.components);
            this.cmsniMini = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmShowMain = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmExit = new System.Windows.Forms.ToolStripMenuItem();
            this.cmsDgv = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmCopyLog = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMessageInfo)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.cmsniMini.SuspendLayout();
            this.cmsDgv.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmMian,
            this.tsmConfig});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(956, 25);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsmMian
            // 
            this.tsmMian.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmCreateDatabase,
            this.tsmCreateMySql,
            this.tsmLogPath,
            this.tsmMini});
            this.tsmMian.Name = "tsmMian";
            this.tsmMian.Size = new System.Drawing.Size(44, 21);
            this.tsmMian.Text = "程序";
            // 
            // tsmCreateDatabase
            // 
            this.tsmCreateDatabase.Name = "tsmCreateDatabase";
            this.tsmCreateDatabase.Size = new System.Drawing.Size(212, 22);
            this.tsmCreateDatabase.Text = "新建数据库(SQLSERVER)";
            this.tsmCreateDatabase.Click += new System.EventHandler(this.TsmCreateDatabase_Click);
            // 
            // tsmLogPath
            // 
            this.tsmLogPath.Name = "tsmLogPath";
            this.tsmLogPath.Size = new System.Drawing.Size(212, 22);
            this.tsmLogPath.Text = "打开日志目录";
            this.tsmLogPath.Click += new System.EventHandler(this.TsmLogPath_Click);
            // 
            // tsmCreateMySql
            // 
            this.tsmCreateMySql.Name = "tsmCreateMySql";
            this.tsmCreateMySql.Size = new System.Drawing.Size(212, 22);
            this.tsmCreateMySql.Text = "新建数据库(MYSQL)";
            this.tsmCreateMySql.Click += new System.EventHandler(this.TsmCreateMySql_Click);
            // 
            // tsmMini
            // 
            this.tsmMini.Name = "tsmMini";
            this.tsmMini.Size = new System.Drawing.Size(212, 22);
            this.tsmMini.Text = "最小化到托盘";
            // 
            // tsmConfig
            // 
            this.tsmConfig.Name = "tsmConfig";
            this.tsmConfig.Size = new System.Drawing.Size(44, 21);
            this.tsmConfig.Text = "设置";
            // 
            // dgvMessageInfo
            // 
            this.dgvMessageInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvMessageInfo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMessageInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMessageInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CreateTime,
            this.LogMessageTypeText,
            this.MessageText});
            this.dgvMessageInfo.Location = new System.Drawing.Point(0, 28);
            this.dgvMessageInfo.MultiSelect = false;
            this.dgvMessageInfo.Name = "dgvMessageInfo";
            this.dgvMessageInfo.RowTemplate.Height = 23;
            this.dgvMessageInfo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMessageInfo.Size = new System.Drawing.Size(956, 475);
            this.dgvMessageInfo.TabIndex = 5;
            // 
            // CreateTime
            // 
            this.CreateTime.HeaderText = "时间";
            this.CreateTime.Name = "CreateTime";
            // 
            // LogMessageTypeText
            // 
            this.LogMessageTypeText.HeaderText = "消息类型";
            this.LogMessageTypeText.Name = "LogMessageTypeText";
            // 
            // MessageText
            // 
            this.MessageText.HeaderText = "消息";
            this.MessageText.Name = "MessageText";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslTime,
            this.tslName});
            this.statusStrip1.Location = new System.Drawing.Point(0, 505);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(956, 22);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tslTime
            // 
            this.tslTime.Name = "tslTime";
            this.tslTime.Size = new System.Drawing.Size(0, 17);
            // 
            // tslName
            // 
            this.tslName.Name = "tslName";
            this.tslName.Size = new System.Drawing.Size(941, 17);
            this.tslName.Spring = true;
            this.tslName.Text = "江苏芍园科技有限责任公司";
            this.tslName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // niMini
            // 
            this.niMini.ContextMenuStrip = this.cmsniMini;
            this.niMini.Icon = ((System.Drawing.Icon)(resources.GetObject("niMini.Icon")));
            this.niMini.Text = "dll自动注册程序";
            this.niMini.Visible = true;
            this.niMini.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.NiMini_MouseDoubleClick);
            // 
            // cmsniMini
            // 
            this.cmsniMini.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmShowMain,
            this.tsmExit});
            this.cmsniMini.Name = "cmsniMini";
            this.cmsniMini.Size = new System.Drawing.Size(101, 48);
            // 
            // tsmShowMain
            // 
            this.tsmShowMain.Name = "tsmShowMain";
            this.tsmShowMain.Size = new System.Drawing.Size(100, 22);
            this.tsmShowMain.Text = "显示";
            // 
            // tsmExit
            // 
            this.tsmExit.Name = "tsmExit";
            this.tsmExit.Size = new System.Drawing.Size(100, 22);
            this.tsmExit.Text = "退出";
            // 
            // cmsDgv
            // 
            this.cmsDgv.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmCopyLog});
            this.cmsDgv.Name = "cmsDgv";
            this.cmsDgv.Size = new System.Drawing.Size(149, 26);
            // 
            // tsmCopyLog
            // 
            this.tsmCopyLog.Name = "tsmCopyLog";
            this.tsmCopyLog.Size = new System.Drawing.Size(148, 22);
            this.tsmCopyLog.Text = "复制此条记录";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 527);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dgvMessageInfo);
            this.Controls.Add(this.menuStrip1);
            this.Name = "MainForm";
            this.Text = "主界面";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMessageInfo)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.cmsniMini.ResumeLayout(false);
            this.cmsDgv.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmMian;
        private System.Windows.Forms.ToolStripMenuItem tsmCreateDatabase;
        private System.Windows.Forms.ToolStripMenuItem tsmLogPath;
        private System.Windows.Forms.ToolStripMenuItem tsmCreateMySql;
        private System.Windows.Forms.ToolStripMenuItem tsmMini;
        private System.Windows.Forms.ToolStripMenuItem tsmConfig;
        private System.Windows.Forms.DataGridView dgvMessageInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn LogMessageTypeText;
        private System.Windows.Forms.DataGridViewTextBoxColumn MessageText;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tslTime;
        private System.Windows.Forms.ToolStripStatusLabel tslName;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.NotifyIcon niMini;
        private System.Windows.Forms.ContextMenuStrip cmsniMini;
        private System.Windows.Forms.ToolStripMenuItem tsmShowMain;
        private System.Windows.Forms.ToolStripMenuItem tsmExit;
        private System.Windows.Forms.ContextMenuStrip cmsDgv;
        private System.Windows.Forms.ToolStripMenuItem tsmCopyLog;
    }
}

