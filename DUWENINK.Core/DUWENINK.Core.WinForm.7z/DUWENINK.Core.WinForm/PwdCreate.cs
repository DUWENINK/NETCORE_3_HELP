﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    PwdCreate
// 文 件 名：    PwdCreate
// 创建者：      DUWENINK
// 创建日期：	2019/7/28 16:28:23
// 版本	日期					修改人	
// v0.1	2019/7/28 16:28:23	DUWENINK
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DUWENINK.Core.WinForm
{
    /// <summary>
    /// 命名空间： CreateDb
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/7/28 16:28:23
    /// 类名：     PwdCreate
    /// </summary>
    public class PwdCreate
    {
        private static char[] constant =
      {
        '0','1','2','3','4','5','6','7','8','9',
        'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
      };
        public  string GenerateRandom(int Length=14)
        {
            System.Text.StringBuilder newRandom = new System.Text.StringBuilder(62);
            Random rd = new Random();
            for (int i = 0; i < Length; i++)
            {
                newRandom.Append(constant[rd.Next(62)]);
            }
            return newRandom.ToString();
        }

    }
}
