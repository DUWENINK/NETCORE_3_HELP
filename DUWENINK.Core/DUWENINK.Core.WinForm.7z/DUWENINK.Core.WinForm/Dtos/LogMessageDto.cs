﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    LogMessageDto
// 文 件 名：    LogMessageDto
// 创建者：      DUWENINK
// 创建日期：	2019/8/1 14:37:56
// 版本	日期					修改人	
// v0.1	2019/8/1 14:37:56	DUWENINK
//----------------------------------------------------------------*/
using DUWENINK.Core.WinForm.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DUWENINK.Core.WinForm.Extensions;
namespace DUWENINK.Core.WinForm.Dtos
{
    /// <summary>
    /// 命名空间： DUWENINK.Core.WinForm.Dtos
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/8/1 14:37:56
    /// 类名：     LogMessageDto
    /// </summary>
    /// <summary>
    /// 显示到dv上的信息
    /// </summary>
    public class LogMessageDto
    {
        /// <summary>
        /// 发生时间
        /// </summary>
        public DateTime CreateTime => DateTime.Now;
        /// <summary>
        /// 消息类型
        /// </summary>
        public LogMessageType LogMessageType { get; set; } = LogMessageType.MessagePush;

        /// <summary>
        /// 消息类型
        /// </summary>
        public string LogMessageTypeText => LogMessageType.GetDescription();

        /// <summary>
        /// 消息内容
        /// </summary>
        public string MessageText { get; set; }
    }
}
