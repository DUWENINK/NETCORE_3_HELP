﻿using DUWENINK.Core.WinForm.Dtos;
using DUWENINK.Core.WinForm.Enum;
using DUWENINK.Core.WinForm.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DUWENINK.Core.WinForm
{
    public partial class MainForm : Form
    {
        //主线程设置委托,子线程传递方法实现dgv刷新逻辑,避免直接跨线程操作
        delegate void SetdgvCallback(LogMessageDto message);
        public string ServerLogPath = Path.Combine(Directory.GetCurrentDirectory(), "logs");//日志文件夹
        //服务归档目录,程序会将`服务注册目录`中注册好的dll归档到'此目录/成功',如果失败则归档到'此目录/失败'其中子目录是根据枚举类定义的
        private readonly string _serviceArchivedPath = ConfigurationManager.AppSettings["ServiceArchivedPath"] ?? string.Empty;
        public MainForm()
        {
            InitializeComponent();
            if (!Directory.Exists(ServerLogPath))
            {
                Directory.CreateDirectory(ServerLogPath);
            }

            // CheckForIllegalCrossThreadCalls = false;
            dgvMessageInfo.AllowUserToAddRows = false;
            niMini.Visible = true;
            ShowInTaskbar = true;
            //from 薄荷


        }

        private void MainForm_Load(object sender, EventArgs e)
        {




        }
        #region 日志信息处理
        /// <summary>
        /// 往dgv追加信息
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="message"></param>
        public void AppendMessage(LogMessageDto message)
        {
            if (dgvMessageInfo.InvokeRequired)//如果调用控件的线程和创建创建控件的线程不是同一个则为True
            {
                while (!dgvMessageInfo.IsHandleCreated)
                {
                    //解决窗体关闭时出现“访问已释放句柄“的异常
                    if (dgvMessageInfo.Disposing || dgvMessageInfo.IsDisposed)
                        return;
                }
                SetdgvCallback d = new SetdgvCallback(AppendMessage);
                this.dgvMessageInfo.Invoke(d, new object[] { message });
            }
            else//直接更新主线程
            {
                int index = dgvMessageInfo.Rows.Add();
                dgvMessageInfo.Rows[index].Cells[0].Value = message.CreateTime;
                dgvMessageInfo.Rows[index].Cells[1].Value = message.LogMessageTypeText;
                dgvMessageInfo.Rows[index].Cells[2].Value = message.MessageText;
                switch (message.LogMessageType)
                {
                    //消息推送
                    case LogMessageType.MessagePush:
                        dgvMessageInfo.Rows[index].DefaultCellStyle.BackColor = Color.White; //Info
                        ShowInNotifyIcon(message, ToolTipIcon.Info);
                        break;
                        
                    //文章生成
                    case LogMessageType.MarkDownCreate:
                        dgvMessageInfo.Rows[index].DefaultCellStyle.BackColor = Color.AliceBlue; //Debug
                        ShowInNotifyIcon(message, ToolTipIcon.Info);
                        break;
                    //数据库建立
                    case LogMessageType.CreateDataBase:
                        dgvMessageInfo.Rows[index].DefaultCellStyle.BackColor = Color.Green; //Debug
                        ShowInNotifyIcon(message, ToolTipIcon.Info);
                        break;
                    default:
                        dgvMessageInfo.Rows[index].DefaultCellStyle.BackColor = Color.Red;
                        ShowInNotifyIcon(message, ToolTipIcon.Error);
                        break;

                }
                dgvMessageInfo.FirstDisplayedScrollingRowIndex = dgvMessageInfo.Rows.Count - 1;




            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="toolTipIcon"></param>
        /// <param name="alwaysShow">总是显示</param>
        public void ShowInNotifyIcon(LogMessageDto message, ToolTipIcon toolTipIcon, bool alwaysShow = false)
        {
            if (alwaysShow)
            {
                niMini.ShowBalloonTip(1000, message.LogMessageTypeText, message.MessageText, toolTipIcon);//警告图标
            }
            else
            {
                if (WindowState == FormWindowState.Minimized)
                {
                    // niMini.Visible = true;//显示此种效果
                    niMini.ShowBalloonTip(1000, message.LogMessageTypeText, message.MessageText, toolTipIcon);//警告图标
                }
            }
        }


        /// <summary>
        /// 写日志(同时显示到dgv)
        /// </summary>
        /// <param name="message"></param>
        public void WriteLogFile(LogMessageDto message)
        {
            AppendMessage(message);
            WriteLogFile($"{message.LogMessageTypeText}  {message.MessageText}");
        }
        /// <summary>
        /// 写日志
        /// </summary>
        /// <param name="dbLog"></param>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void WriteLogFile(string dbLog)
        {
            var ServerLogFilePath = Path.Combine(ServerLogPath, DateTime.Now.ToString("yyyyMMdd") + "_log.log");
            using (StreamWriter sw = new StreamWriter(ServerLogFilePath, true, Encoding.Default))
            {
                sw.WriteLine($"{DateTime.Now}：{dbLog}");
                sw.Dispose();
                sw.Close();
            }
        }

        #endregion
        private void TsmCreateDatabase_Click(object sender, EventArgs e)
        {
            var form = new CreateDatabaseForm();
            form.LogEvent += WriteLogFile;
            form.Show();
        }

        private void NiMini_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                //还原窗体显示    
                WindowState = FormWindowState.Normal;
                //激活窗体并给予它焦点
                this.Activate();
                //任务栏区显示图标
                this.ShowInTaskbar = true;
                //托盘区图标隐藏
                //  niMini.Visible = false;
            }
        }

        private void TsmCreateMySql_Click(object sender, EventArgs e)
        {
            var form = new CreateDatabaseForm();
            form.LogEvent += WriteLogFile;
            form.Show();
        }

        private void TsmLogPath_Click(object sender, EventArgs e)
        {
            OpenDirectory(ServerLogPath);
        }
        #region 打开文件夹

        /// <summary>
        /// 打开文件目录
        /// </summary>
        /// <param name="directoryPath"></param>
        public void OpenDirectory(string directoryPath)
        {
            if (!Directory.Exists(directoryPath))
            {
                WriteLogFile(new LogMessageDto { LogMessageType = LogMessageType.Warring, MessageText = $"文件路径{directoryPath}不存在,无法打开" });
            }
            System.Diagnostics.Process.Start(directoryPath);
        }
        /// <summary>
        /// 打开文件目录
        /// </summary>
        /// <param name="directoryPath"></param>
        /// <param name="archiveFileType"></param>
        public void OpenDirectory(string directoryPath, ArchiveFileType archiveFileType)
        {
            OpenDirectory(Path.Combine(directoryPath, archiveFileType.GetDescription()));
        }
        #endregion
    }
}
