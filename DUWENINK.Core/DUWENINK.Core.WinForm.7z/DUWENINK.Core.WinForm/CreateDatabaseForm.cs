﻿using DUWENINK.Core.WinForm.Dtos;
using DUWENINK.Core.WinForm.Entitys;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DUWENINK.Core.WinForm
{
    public delegate void logDele(LogMessageDto dto);//声明代理  
    public partial class CreateDatabaseForm : Form
    {

        public event logDele LogEvent;//声明事件  
        public CreateDatabaseForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 往主窗体写入日志
        /// </summary>
        /// <param name="dto"></param>
        public void AddMainLog(LogMessageDto dto)
        {
            LogEvent?.Invoke(dto);//触发事件  
        }



        private void CreateDatabaseForm_Load(object sender, EventArgs e)
        {
            var list = new List<Db>();
            var db2017 = new Db
            {
                Text = "2017",
                Value = "Data Source = ddns.duwen.ink,21417; Initial Catalog = master; User ID = sa; Password = duwenink123.0",
            };

            var db2016 = new Db
            {
                Text = "2016",
                Value = "Data Source = ddns.duwen.ink,21416; Initial Catalog = master; User ID = sa; Password = duwenink123.0",
            };
            var db2014 = new Db
            {
                Text = "2014",
                Value = "Data Source = ddns.duwen.ink,21414; Initial Catalog = master; User ID = sa; Password = duwenink123.0",
            };
            var db2012 = new Db
            {
                Text = "2012",
                Value = "Data Source = ddns.duwen.ink,21412; Initial Catalog = master; User ID = sa; Password = duwenink123.0",
            };
            var db2008 = new Db
            {
                Text = "2008",
                Value = "Data Source = ddns.duwen.ink,21408; Initial Catalog = master; User ID = sa; Password = duwenink123.0",
            };
            list.Add(db2017);
            list.Add(db2016);
            list.Add(db2014);
            list.Add(db2012);
            list.Add(db2008);

            comboBox1.DataSource = list;
            comboBox1.DisplayMember = "Text";
            comboBox1.ValueMember = "Value";
        }


    

        public void IfNotExistThenCreate(string conn)
        {
            var helper = new SqlHelper(conn);
            if (helper.ExecuteScalar($"SELECT * FROM sysdatabases WHERE name='icodedockconfig'") == null)
            {
                //新建配置数据库
                helper.ExecuteNonQuery($"CREATE DATABASE icodedockconfig");
                //建表
                string csql = @"USE [icodedockconfig];
CREATE TABLE[dbo].[dbconfig](

    [Id][int] IDENTITY(1, 1) NOT NULL,
[DbName] [nvarchar]
        (50) NULL,
    [ConStr] [nvarchar]
        (max) NULL,
 CONSTRAINT[PK_dbconfig] PRIMARY KEY CLUSTERED
(
   [Id] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
) ON[PRIMARY] TEXTIMAGE_ON[PRIMARY];";
                helper.ExecuteNonQuery(csql);
            }
        }



        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                var dbName = textBox1.Text.Trim().ToLower();
                if (string.IsNullOrEmpty(comboBox1.SelectedValue?.ToString() ?? string.Empty) || string.IsNullOrEmpty(dbName) || dbName == "icodedockconfig")
                {
                    AddMainLog(new LogMessageDto { LogMessageType = Enum.LogMessageType.CreateDataBaseError, MessageText = "请检查数据库链接和数据库名称" });
                    return;
                }
                var helper = new SqlHelper(comboBox1.SelectedValue.ToString());
                IfNotExistThenCreate(comboBox1.SelectedValue.ToString());

                var Exist = helper.ExecuteScalar($"SELECT * FROM sysdatabases WHERE name='{dbName}'");
                var existFromTable = helper.ExecuteScalar($"use icodedockconfig; SELECT * FROM dbconfig WHERE DbName='{dbName}'");
                if ((Exist != null)|| (existFromTable != null))
                {
                    AddMainLog(new LogMessageDto { LogMessageType = Enum.LogMessageType.CreateDataBaseError, MessageText = "数据库已经存在,你重新选择数据库吧(请检查数据库实例和配置库)" });
                    return;
                }
                else
                {
                    //新建数据库
                    var ss = helper.ExecuteNonQuery($"CREATE DATABASE {dbName}");
                    var pwd = new PwdCreate().GenerateRandom();
                    helper.ExecuteNonQuery($" use {dbName} ;exec sp_addlogin  '{dbName}','{pwd}','{dbName}'");
                    helper.ExecuteNonQuery($"use {dbName} ; exec sp_grantdbaccess  '{dbName}','{dbName}'");
                    helper.ExecuteNonQuery($"use {dbName} ; EXEC sp_addrolemember 'db_owner', '{dbName}'");

                    var contemp = $"Data Source = ddns.duwen.ink,214{comboBox1.Text.Substring(2)}; Initial Catalog = {dbName}; User ID = {dbName}; Password = {pwd} ";
                    helper.ExecuteNonQuery($"USE [icodedockconfig];insert dbconfig(DbName,ConStr) values ('{dbName}','{contemp}')");
                    dataGridView1.DataSource = GetList(comboBox1.SelectedValue.ToString(), dbName);
                    AddMainLog(new LogMessageDto { LogMessageType = Enum.LogMessageType.CreateDataBase, MessageText = $"数据库新建成功 数据库名称{dbName} 密码{pwd}" });
                }

            }
            catch (Exception ex)
            {

                AddMainLog(new LogMessageDto { LogMessageType = Enum.LogMessageType.CreateDataBaseError, MessageText = $"实不相瞒,你的程序异常了{ex.Message}" });
              
            }


        }

        private void Button2_Click(object sender, EventArgs e)
        {
            var dbName = textBox1.Text.Trim().ToLower();
            if (string.IsNullOrEmpty(comboBox1.SelectedValue?.ToString() ?? string.Empty))
            {
                MessageBox.Show("请检查数据库链接和数据库名称");
                return;
            }
            var helper = new SqlHelper(comboBox1.SelectedValue.ToString());
            IfNotExistThenCreate(comboBox1.SelectedValue.ToString());

            dataGridView1.DataSource = GetList(comboBox1.SelectedValue.ToString(), textBox1.Text);




        }

        private DataTable GetList(string conn, string dbName)
        {
            var helper = new SqlHelper(conn);
            string sql = "USE [icodedockconfig];select  *  from [dbconfig] where 1=1 ";

            if (!string.IsNullOrEmpty(dbName))
            {
                sql += $" and dbName='{dbName}'";
            }
            var table = helper.ExecuteDataTable(sql);

            return table;

        }

       
    }
}
