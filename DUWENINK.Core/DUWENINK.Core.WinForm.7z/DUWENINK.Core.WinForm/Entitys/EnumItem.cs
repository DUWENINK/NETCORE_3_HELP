﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    EnumItem
// 文 件 名：    EnumItem
// 创建者：      DUWENINK
// 创建日期：	2019/8/1 14:44:25
// 版本	日期					修改人	
// v0.1	2019/8/1 14:44:25	DUWENINK
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DUWENINK.Core.WinForm.Entitys
{
    /// <summary>
    /// 命名空间： DUWENINK.Core.WinForm.Entitys
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/8/1 14:44:25
    /// 类名：     EnumItem(枚举列)
    /// </summary>
    public class EnumItem
    {
        /// <summary>
        /// 值
        /// </summary>
        public int Value { get; set; }
        /// <summary>
        /// 键
        /// </summary>
        public string Text { get; set; }
    }
}
