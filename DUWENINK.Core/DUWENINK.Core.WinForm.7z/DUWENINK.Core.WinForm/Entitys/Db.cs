﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    Db
// 文 件 名：    Db
// 创建者：      DUWENINK
// 创建日期：	2019/8/1 17:23:10
// 版本	日期					修改人	
// v0.1	2019/8/1 17:23:10	DUWENINK
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DUWENINK.Core.WinForm.Entitys
{
    /// <summary>
    /// 命名空间： DUWENINK.Core.WinForm.Entitys
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/8/1 17:23:10
    /// 类名：     Db
    /// </summary>
    public class Db
    {
        public string Text { get; set; }
        public string Value { get; set; }

    }
}
