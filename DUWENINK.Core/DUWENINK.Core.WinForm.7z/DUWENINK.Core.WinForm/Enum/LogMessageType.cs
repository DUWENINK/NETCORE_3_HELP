﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    LogMessageType
// 文 件 名：    LogMessageType
// 创建者：      DUWENINK
// 创建日期：	2019/8/1 14:38:34
// 版本	日期					修改人	
// v0.1	2019/8/1 14:38:34	DUWENINK
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DUWENINK.Core.WinForm.Enum
{
    /// <summary>
    /// 命名空间： DUWENINK.Core.WinForm.Enum
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/8/1 14:38:34
    /// 类名：     LogMessageType
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    [Description("错误消息类型")]
    public enum LogMessageType
    {




        /// <summary>
        /// 消息推送
        /// </summary>
        [Description("消息推送")]
        MessagePush = 0,
        /// <summary>
        /// 消息推送-错误
        /// </summary>
        [Description("消息推送-错误")]
        MessagePushError = 1,
        /// <summary>
        /// 文章生成
        /// </summary>
        [Description("文章生成")]
        MarkDownCreate = 2,
        /// <summary>
        /// 文章生成-错误
        /// </summary>
        [Description("文章生成-错误")]
        MarkDownCreateError = 3,
        /// <summary>
        /// 数据库新建
        /// </summary>
        [Description("数据库新建")]
        CreateDataBase =4,
        /// <summary>
        /// 数据库新建-错误
        /// </summary>
        [Description("数据库新建-错误")]
        CreateDataBaseError = 5,
        /// <summary>
        /// 数据库新建-错误
        /// </summary>
        [Description("警告")]
        Warring = 6,

    }
}
