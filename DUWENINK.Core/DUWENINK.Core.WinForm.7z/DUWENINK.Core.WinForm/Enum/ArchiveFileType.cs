﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    ArchiveFileType
// 文 件 名：    ArchiveFileType
// 创建者：      DUWENINK
// 创建日期：	2019/8/1 16:30:32
// 版本	日期					修改人	
// v0.1	2019/8/1 16:30:32	DUWENINK
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DUWENINK.Core.WinForm.Enum
{
    /// <summary>
    /// 命名空间： DUWENINK.Core.WinForm.Enum
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/8/1 16:30:32
    /// 类名：     ArchiveFileType
    /// </summary>
    [Description("归档文件类型")]
    public enum ArchiveFileType
    {
        /// <summary>
        /// 此枚举值表示dll为新增进来的,成功标识,产生xml需要一同归档
        /// </summary>
        [Description("成功-文章生成成功")]
        Add = 0,
        /// <summary>
        /// 此枚举值表示dll为新增或者更新但是由于缺少XML无法注册,不产生XML文档,只归档Dll文件
        /// </summary>
        [Description("失败-文件格式问题")]
        LackXmlFile = 1,
        /// <summary>
        /// 由于种种原因,dll无法注册,失败标识,不一定存在xml文档
        /// </summary>
        [Description("失败-其他原因")]
        Failed = 2,
        
    }
}
