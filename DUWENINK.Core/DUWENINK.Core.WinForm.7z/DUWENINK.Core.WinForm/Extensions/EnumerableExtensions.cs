﻿/*----------------------------------------------------------------
// Copyright © 2019 Chinairap.All rights reserved. 
// CLR版本：	4.0.30319.42000
// 类 名 称：    EnumerableExtensions
// 文 件 名：    EnumerableExtensions
// 创建者：      DUWENINK
// 创建日期：	2019/8/1 14:42:55
// 版本	日期					修改人	
// v0.1	2019/8/1 14:42:55	DUWENINK
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DUWENINK.Core.WinForm.Entitys;

namespace DUWENINK.Core.WinForm.Extensions
{
    /// <summary>
    /// 命名空间： DUWENINK.Core.WinForm.Extensions
    /// 创建者：   DUWENINK
    /// 创建日期： 2019/8/1 14:42:55
    /// 类名：     EnumerableExtensions
    /// </summary>
    public static class EnumerableExtensions
    {
        /// <summary>
        /// 获取枚举类的名称
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetDescription<TEnum>(this TEnum value)
        {
            var fi = value.GetType().GetField(value.ToString());

            if (fi != null)
            {
                var attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes.Length > 0)
                {
                    return attributes[0].Description;
                }
            }

            return value.ToString();
        }

        /// <summary>
        /// 获取枚举列表
        /// </summary>
        public static List<EnumItem> SelectList<T>() where T : struct
        {
            Type t = typeof(T);
            return t.IsEnum ? System.Enum.GetValues(t)
                .Cast<System.Enum>()
                .ToList()
                .ConvertAll(c => new EnumItem { Text = c.GetDescription(), Value = Convert.ToInt32(c) }) : null;
        }
    }
}
